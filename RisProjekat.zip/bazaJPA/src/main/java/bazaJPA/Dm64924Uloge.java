package bazaJPA;

import java.io.Serializable;
import jakarta.persistence.*;
import java.util.List;


/**
 * The persistent class for the dm64924_uloge database table.
 * 
 */
@Entity
@Table(name="dm64924_uloge")
@NamedQuery(name="Dm64924Uloge.findAll", query="SELECT d FROM Dm64924Uloge d")
public class Dm64924Uloge implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idUloge;

	private String naziv;

	//bi-directional many-to-one association to Dm64924Korisnici
	@OneToMany(mappedBy="dm64924Uloge")
	private List<Dm64924Korisnici> dm64924Korisnicis;

	public Dm64924Uloge() {
	}

	public int getIdUloge() {
		return this.idUloge;
	}

	public void setIdUloge(int idUloge) {
		this.idUloge = idUloge;
	}

	public String getNaziv() {
		return this.naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public List<Dm64924Korisnici> getDm64924Korisnicis() {
		return this.dm64924Korisnicis;
	}

	public void setDm64924Korisnicis(List<Dm64924Korisnici> dm64924Korisnicis) {
		this.dm64924Korisnicis = dm64924Korisnicis;
	}

	public Dm64924Korisnici addDm64924Korisnici(Dm64924Korisnici dm64924Korisnici) {
		getDm64924Korisnicis().add(dm64924Korisnici);
		dm64924Korisnici.setDm64924Uloge(this);

		return dm64924Korisnici;
	}

	public Dm64924Korisnici removeDm64924Korisnici(Dm64924Korisnici dm64924Korisnici) {
		getDm64924Korisnicis().remove(dm64924Korisnici);
		dm64924Korisnici.setDm64924Uloge(null);

		return dm64924Korisnici;
	}

}