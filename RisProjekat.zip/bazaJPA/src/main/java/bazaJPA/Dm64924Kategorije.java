package bazaJPA;

import java.io.Serializable;
import jakarta.persistence.*;
import java.util.List;


/**
 * The persistent class for the dm64924_kategorije database table.
 * 
 */
@Entity
@Table(name="dm64924_kategorije")
@NamedQuery(name="Dm64924Kategorije.findAll", query="SELECT d FROM Dm64924Kategorije d")
public class Dm64924Kategorije implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idKategorije;

	private String naziv;

	private String opis;

	//bi-directional many-to-one association to Dm64924Proizvodi
	@OneToMany(mappedBy="dm64924Kategorije")
	private List<Dm64924Proizvodi> dm64924Proizvodis;

	public Dm64924Kategorije() {
	}

	public int getIdKategorije() {
		return this.idKategorije;
	}

	public void setIdKategorije(int idKategorije) {
		this.idKategorije = idKategorije;
	}

	public String getNaziv() {
		return this.naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public String getOpis() {
		return this.opis;
	}

	public void setOpis(String opis) {
		this.opis = opis;
	}

	public List<Dm64924Proizvodi> getDm64924Proizvodis() {
		return this.dm64924Proizvodis;
	}

	public void setDm64924Proizvodis(List<Dm64924Proizvodi> dm64924Proizvodis) {
		this.dm64924Proizvodis = dm64924Proizvodis;
	}

	public Dm64924Proizvodi addDm64924Proizvodi(Dm64924Proizvodi dm64924Proizvodi) {
		getDm64924Proizvodis().add(dm64924Proizvodi);
		dm64924Proizvodi.setDm64924Kategorije(this);

		return dm64924Proizvodi;
	}

	public Dm64924Proizvodi removeDm64924Proizvodi(Dm64924Proizvodi dm64924Proizvodi) {
		getDm64924Proizvodis().remove(dm64924Proizvodi);
		dm64924Proizvodi.setDm64924Kategorije(null);

		return dm64924Proizvodi;
	}

}