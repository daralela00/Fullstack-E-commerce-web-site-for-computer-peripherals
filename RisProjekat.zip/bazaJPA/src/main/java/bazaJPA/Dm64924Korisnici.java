package bazaJPA;

import java.io.Serializable;
import jakarta.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the dm64924_korisnici database table.
 * 
 */
@Entity
@Table(name="dm64924_korisnici")
@NamedQuery(name="Dm64924Korisnici.findAll", query="SELECT d FROM Dm64924Korisnici d")
public class Dm64924Korisnici implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idKorisnici;

	private String email;

	@Temporal(TemporalType.TIMESTAMP)
	private Date kreiran;

	private String password;

	private String username;

	//bi-directional many-to-one association to Dm64924Uloge
	@ManyToOne
@JoinColumn(name="dm64924_uloge_idUloge")
	private Dm64924Uloge dm64924Uloge;

	//bi-directional many-to-one association to Dm64924Narudzbine
	@OneToMany(mappedBy="dm64924Korisnici")
	private List<Dm64924Narudzbine> dm64924Narudzbines;

	//bi-directional many-to-one association to Dm64924Recenzije
	@OneToMany(mappedBy="dm64924Korisnici")
	private List<Dm64924Recenzije> dm64924Recenzijes;

	public Dm64924Korisnici() {
	}

	public int getIdKorisnici() {
		return this.idKorisnici;
	}

	public void setIdKorisnici(int idKorisnici) {
		this.idKorisnici = idKorisnici;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getKreiran() {
		return this.kreiran;
	}

	public void setKreiran(Date kreiran) {
		this.kreiran = kreiran;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Dm64924Uloge getDm64924Uloge() {
		return this.dm64924Uloge;
	}

	public void setDm64924Uloge(Dm64924Uloge dm64924Uloge) {
		this.dm64924Uloge = dm64924Uloge;
	}

	public List<Dm64924Narudzbine> getDm64924Narudzbines() {
		return this.dm64924Narudzbines;
	}

	public void setDm64924Narudzbines(List<Dm64924Narudzbine> dm64924Narudzbines) {
		this.dm64924Narudzbines = dm64924Narudzbines;
	}

	public Dm64924Narudzbine addDm64924Narudzbine(Dm64924Narudzbine dm64924Narudzbine) {
		getDm64924Narudzbines().add(dm64924Narudzbine);
		dm64924Narudzbine.setDm64924Korisnici(this);

		return dm64924Narudzbine;
	}

	public Dm64924Narudzbine removeDm64924Narudzbine(Dm64924Narudzbine dm64924Narudzbine) {
		getDm64924Narudzbines().remove(dm64924Narudzbine);
		dm64924Narudzbine.setDm64924Korisnici(null);

		return dm64924Narudzbine;
	}

	public List<Dm64924Recenzije> getDm64924Recenzijes() {
		return this.dm64924Recenzijes;
	}

	public void setDm64924Recenzijes(List<Dm64924Recenzije> dm64924Recenzijes) {
		this.dm64924Recenzijes = dm64924Recenzijes;
	}

	public Dm64924Recenzije addDm64924Recenzije(Dm64924Recenzije dm64924Recenzije) {
		getDm64924Recenzijes().add(dm64924Recenzije);
		dm64924Recenzije.setDm64924Korisnici(this);

		return dm64924Recenzije;
	}

	public Dm64924Recenzije removeDm64924Recenzije(Dm64924Recenzije dm64924Recenzije) {
		getDm64924Recenzijes().remove(dm64924Recenzije);
		dm64924Recenzije.setDm64924Korisnici(null);

		return dm64924Recenzije;
	}

}