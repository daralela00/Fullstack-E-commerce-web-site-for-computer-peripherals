package bazaJPA;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the dm64924_proizvodi database table.
 * 
 */
@Entity
@Table(name="dm64924_proizvodi")
@NamedQuery(name="Dm64924Proizvodi.findAll", query="SELECT d FROM Dm64924Proizvodi d")
public class Dm64924Proizvodi implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idProizvodi;

	private BigDecimal cena;

	@Temporal(TemporalType.TIMESTAMP)
	private Date kreiran;

	private int lager;

	private String naziv;

	private String opis;

	//bi-directional many-to-one association to Dm64924Kategorije
	@ManyToOne
@JoinColumn(name="dm64924_kategorije_idKategorije")
	private Dm64924Kategorije dm64924Kategorije;

	//bi-directional many-to-one association to Dm64924Recenzije
	@OneToMany(mappedBy="dm64924Proizvodi")
	private List<Dm64924Recenzije> dm64924Recenzijes;
	
	// ovaj onetomany tag je izmenjen naknadno da bi mogle da se ucitaju slike koje se naknadno dodaju za proizvode preko admina
	//bi-directional many-to-one association to Dm64924Slikeproizvoda
	@OneToMany(mappedBy="dm64924Proizvodi",  fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Dm64924Slikeproizvoda> dm64924Slikeproizvodas;
	
	//Isto kao iznad
	//bi-directional many-to-one association to Dm64924Stavkenarudzbine
	@OneToMany(mappedBy = "dm64924Proizvodi", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Dm64924Stavkenarudzbine> dm64924Stavkenarudzbines;

	public Dm64924Proizvodi() {
	}

	public int getIdProizvodi() {
		return this.idProizvodi;
	}

	public void setIdProizvodi(int idProizvodi) {
		this.idProizvodi = idProizvodi;
	}

	public BigDecimal getCena() {
		return this.cena;
	}

	public void setCena(BigDecimal cena) {
		this.cena = cena;
	}

	public Date getKreiran() {
		return this.kreiran;
	}

	public void setKreiran(Date kreiran) {
		this.kreiran = kreiran;
	}

	public int getLager() {
		return this.lager;
	}

	public void setLager(int lager) {
		this.lager = lager;
	}

	public String getNaziv() {
		return this.naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public String getOpis() {
		return this.opis;
	}

	public void setOpis(String opis) {
		this.opis = opis;
	}

	public Dm64924Kategorije getDm64924Kategorije() {
		return this.dm64924Kategorije;
	}

	public void setDm64924Kategorije(Dm64924Kategorije dm64924Kategorije) {
		this.dm64924Kategorije = dm64924Kategorije;
	}

	public List<Dm64924Recenzije> getDm64924Recenzijes() {
		return this.dm64924Recenzijes;
	}

	public void setDm64924Recenzijes(List<Dm64924Recenzije> dm64924Recenzijes) {
		this.dm64924Recenzijes = dm64924Recenzijes;
	}

	public Dm64924Recenzije addDm64924Recenzije(Dm64924Recenzije dm64924Recenzije) {
		getDm64924Recenzijes().add(dm64924Recenzije);
		dm64924Recenzije.setDm64924Proizvodi(this);

		return dm64924Recenzije;
	}

	public Dm64924Recenzije removeDm64924Recenzije(Dm64924Recenzije dm64924Recenzije) {
		getDm64924Recenzijes().remove(dm64924Recenzije);
		dm64924Recenzije.setDm64924Proizvodi(null);

		return dm64924Recenzije;
	}

	public List<Dm64924Slikeproizvoda> getDm64924Slikeproizvodas() {
		return this.dm64924Slikeproizvodas;
	}

	public void setDm64924Slikeproizvodas(List<Dm64924Slikeproizvoda> dm64924Slikeproizvodas) {
		this.dm64924Slikeproizvodas = dm64924Slikeproizvodas;
	}

	public Dm64924Slikeproizvoda addDm64924Slikeproizvoda(Dm64924Slikeproizvoda dm64924Slikeproizvoda) {
		getDm64924Slikeproizvodas().add(dm64924Slikeproizvoda);
		dm64924Slikeproizvoda.setDm64924Proizvodi(this);

		return dm64924Slikeproizvoda;
	}

	public Dm64924Slikeproizvoda removeDm64924Slikeproizvoda(Dm64924Slikeproizvoda dm64924Slikeproizvoda) {
		getDm64924Slikeproizvodas().remove(dm64924Slikeproizvoda);
		dm64924Slikeproizvoda.setDm64924Proizvodi(null);

		return dm64924Slikeproizvoda;
	}

	public List<Dm64924Stavkenarudzbine> getDm64924Stavkenarudzbines() {
		return this.dm64924Stavkenarudzbines;
	}

	public void setDm64924Stavkenarudzbines(List<Dm64924Stavkenarudzbine> dm64924Stavkenarudzbines) {
		this.dm64924Stavkenarudzbines = dm64924Stavkenarudzbines;
	}

	public Dm64924Stavkenarudzbine addDm64924Stavkenarudzbine(Dm64924Stavkenarudzbine dm64924Stavkenarudzbine) {
		getDm64924Stavkenarudzbines().add(dm64924Stavkenarudzbine);
		dm64924Stavkenarudzbine.setDm64924Proizvodi(this);

		return dm64924Stavkenarudzbine;
	}

	public Dm64924Stavkenarudzbine removeDm64924Stavkenarudzbine(Dm64924Stavkenarudzbine dm64924Stavkenarudzbine) {
		getDm64924Stavkenarudzbines().remove(dm64924Stavkenarudzbine);
		dm64924Stavkenarudzbine.setDm64924Proizvodi(null);

		return dm64924Stavkenarudzbine;
	}

}