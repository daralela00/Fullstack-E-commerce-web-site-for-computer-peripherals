package bazaJPA;

import java.io.Serializable;
import jakarta.persistence.*;
import java.util.Date;


/**
 * The persistent class for the dm64924_recenzije database table.
 * 
 */
@Entity
@Table(name="dm64924_recenzije")
@NamedQuery(name="Dm64924Recenzije.findAll", query="SELECT d FROM Dm64924Recenzije d")
public class Dm64924Recenzije implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idRecenzije;

	@Temporal(TemporalType.TIMESTAMP)
	private Date datum;

	private String komentar;

	private int ocena;

	//bi-directional many-to-one association to Dm64924Korisnici
	@ManyToOne
@JoinColumn(name="dm64924_korisnici_idKorisnici")
	private Dm64924Korisnici dm64924Korisnici;

	//bi-directional many-to-one association to Dm64924Proizvodi
	@ManyToOne
@JoinColumn(name="dm64924_proizvodi_idProizvodi")
	private Dm64924Proizvodi dm64924Proizvodi;

	public Dm64924Recenzije() {
	}

	public int getIdRecenzije() {
		return this.idRecenzije;
	}

	public void setIdRecenzije(int idRecenzije) {
		this.idRecenzije = idRecenzije;
	}

	public Date getDatum() {
		return this.datum;
	}

	public void setDatum(Date datum) {
		this.datum = datum;
	}

	public String getKomentar() {
		return this.komentar;
	}

	public void setKomentar(String komentar) {
		this.komentar = komentar;
	}

	public int getOcena() {
		return this.ocena;
	}

	public void setOcena(int ocena) {
		this.ocena = ocena;
	}

	public Dm64924Korisnici getDm64924Korisnici() {
		return this.dm64924Korisnici;
	}

	public void setDm64924Korisnici(Dm64924Korisnici dm64924Korisnici) {
		this.dm64924Korisnici = dm64924Korisnici;
	}

	public Dm64924Proizvodi getDm64924Proizvodi() {
		return this.dm64924Proizvodi;
	}

	public void setDm64924Proizvodi(Dm64924Proizvodi dm64924Proizvodi) {
		this.dm64924Proizvodi = dm64924Proizvodi;
	}

}