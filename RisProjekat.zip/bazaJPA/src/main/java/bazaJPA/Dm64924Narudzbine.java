package bazaJPA;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the dm64924_narudzbine database table.
 * 
 */
@Entity
@Table(name="dm64924_narudzbine")
@NamedQuery(name="Dm64924Narudzbine.findAll", query="SELECT d FROM Dm64924Narudzbine d")
public class Dm64924Narudzbine implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idNarudzbine;

	@Temporal(TemporalType.TIMESTAMP)
	private Date datum;

	private BigDecimal ukupnaCena;

	//bi-directional many-to-one association to Dm64924Korisnici
	@ManyToOne
@JoinColumn(name="dm64924_korisnici_idKorisnici")
	private Dm64924Korisnici dm64924Korisnici;

	//bi-directional many-to-one association to Dm64924Stavkenarudzbine
	@OneToMany(mappedBy="dm64924Narudzbine")
	private List<Dm64924Stavkenarudzbine> dm64924Stavkenarudzbines;

	public Dm64924Narudzbine() {
	}

	public int getIdNarudzbine() {
		return this.idNarudzbine;
	}

	public void setIdNarudzbine(int idNarudzbine) {
		this.idNarudzbine = idNarudzbine;
	}

	public Date getDatum() {
		return this.datum;
	}

	public void setDatum(Date datum) {
		this.datum = datum;
	}

	public BigDecimal getUkupnaCena() {
		return this.ukupnaCena;
	}

	public void setUkupnaCena(BigDecimal ukupnaCena) {
		this.ukupnaCena = ukupnaCena;
	}

	public Dm64924Korisnici getDm64924Korisnici() {
		return this.dm64924Korisnici;
	}

	public void setDm64924Korisnici(Dm64924Korisnici dm64924Korisnici) {
		this.dm64924Korisnici = dm64924Korisnici;
	}

	public List<Dm64924Stavkenarudzbine> getDm64924Stavkenarudzbines() {
		return this.dm64924Stavkenarudzbines;
	}

	public void setDm64924Stavkenarudzbines(List<Dm64924Stavkenarudzbine> dm64924Stavkenarudzbines) {
		this.dm64924Stavkenarudzbines = dm64924Stavkenarudzbines;
	}

	public Dm64924Stavkenarudzbine addDm64924Stavkenarudzbine(Dm64924Stavkenarudzbine dm64924Stavkenarudzbine) {
		getDm64924Stavkenarudzbines().add(dm64924Stavkenarudzbine);
		dm64924Stavkenarudzbine.setDm64924Narudzbine(this);

		return dm64924Stavkenarudzbine;
	}

	public Dm64924Stavkenarudzbine removeDm64924Stavkenarudzbine(Dm64924Stavkenarudzbine dm64924Stavkenarudzbine) {
		getDm64924Stavkenarudzbines().remove(dm64924Stavkenarudzbine);
		dm64924Stavkenarudzbine.setDm64924Narudzbine(null);

		return dm64924Stavkenarudzbine;
	}

}