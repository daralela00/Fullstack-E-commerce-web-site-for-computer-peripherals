package bazaJPA;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the dm64924_stavkenarudzbine database table.
 * 
 */
@Entity
@Table(name="dm64924_stavkenarudzbine")
@NamedQuery(name="Dm64924Stavkenarudzbine.findAll", query="SELECT d FROM Dm64924Stavkenarudzbine d")
public class Dm64924Stavkenarudzbine implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idStavkeNarudzbine;

	private BigDecimal cena;

	private int kolicina;

	//bi-directional many-to-one association to Dm64924Narudzbine
	@ManyToOne
@JoinColumn(name="dm64924_narudzbine_idNarudzbine")
	private Dm64924Narudzbine dm64924Narudzbine;

	//bi-directional many-to-one association to Dm64924Proizvodi
	@ManyToOne
@JoinColumn(name="dm64924_proizvodi_idProizvodi")
	private Dm64924Proizvodi dm64924Proizvodi;

	public Dm64924Stavkenarudzbine() {
	}

	public int getIdStavkeNarudzbine() {
		return this.idStavkeNarudzbine;
	}

	public void setIdStavkeNarudzbine(int idStavkeNarudzbine) {
		this.idStavkeNarudzbine = idStavkeNarudzbine;
	}

	public BigDecimal getCena() {
		return this.cena;
	}

	public void setCena(BigDecimal cena) {
		this.cena = cena;
	}

	public int getKolicina() {
		return this.kolicina;
	}

	public void setKolicina(int kolicina) {
		this.kolicina = kolicina;
	}

	public Dm64924Narudzbine getDm64924Narudzbine() {
		return this.dm64924Narudzbine;
	}

	public void setDm64924Narudzbine(Dm64924Narudzbine dm64924Narudzbine) {
		this.dm64924Narudzbine = dm64924Narudzbine;
	}

	public Dm64924Proizvodi getDm64924Proizvodi() {
		return this.dm64924Proizvodi;
	}

	public void setDm64924Proizvodi(Dm64924Proizvodi dm64924Proizvodi) {
		this.dm64924Proizvodi = dm64924Proizvodi;
	}

}