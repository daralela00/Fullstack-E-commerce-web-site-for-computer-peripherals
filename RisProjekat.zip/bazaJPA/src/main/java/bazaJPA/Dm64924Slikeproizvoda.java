package bazaJPA;

import java.io.Serializable;
import jakarta.persistence.*;


/**
 * The persistent class for the dm64924_slikeproizvoda database table.
 * 
 */
@Entity
@Table(name="dm64924_slikeproizvoda")
@NamedQuery(name="Dm64924Slikeproizvoda.findAll", query="SELECT d FROM Dm64924Slikeproizvoda d")
public class Dm64924Slikeproizvoda implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idSlikeProizvoda;

	private String urlSlike;

	//bi-directional many-to-one association to Dm64924Proizvodi
	@ManyToOne
@JoinColumn(name="dm64924_proizvodi_idProizvodi")
	private Dm64924Proizvodi dm64924Proizvodi;

	public Dm64924Slikeproizvoda() {
	}

	public int getIdSlikeProizvoda() {
		return this.idSlikeProizvoda;
	}

	public void setIdSlikeProizvoda(int idSlikeProizvoda) {
		this.idSlikeProizvoda = idSlikeProizvoda;
	}

	public String getUrlSlike() {
		return this.urlSlike;
	}

	public void setUrlSlike(String urlSlike) {
		this.urlSlike = urlSlike;
	}

	public Dm64924Proizvodi getDm64924Proizvodi() {
		return this.dm64924Proizvodi;
	}

	public void setDm64924Proizvodi(Dm64924Proizvodi dm64924Proizvodi) {
		this.dm64924Proizvodi = dm64924Proizvodi;
	}

}