<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Registracija</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bitcount+Single:wght@100..900&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: rgb(236, 236, 234);
        }

        .navbar-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 40px;
            background-color: #111;
            color: white;
        }

        .brand {
            font-family: "Bitcount Single", system-ui;
            font-weight: 300;
            font-size: 40px;
        }

		.brand a{
			text-decoration: none;
			color: white;
		}

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-size: 16px;
        }

        .nav-links a:hover {
            text-decoration: underline;
        }

        .page-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100vh - 80px);
        }

        .register-container {
            background-color: white;
            padding: 35px 40px;
            width: 360px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        .register-container h2 {
            text-align: center;
            margin-bottom: 25px;
            margin-top: 0px;
        }

        .register-container input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            font-size: 15px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        .register-container button {
            width: 100%;
            padding: 10px;
            background-color: #111;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }
        
        .register-container input,
		.register-container button {
   			box-sizing: border-box;
		}

        .register-container button:hover {
            background-color: #333;
        }
        
        .radio {
		    display: flex;
		    justify-content: space-between;
		    margin-bottom: 15px;
		    padding-right: 20px;
		    padding-left: 20px;
		}
		
		.radio-option {
		    display: flex;
		    align-items: center;
		    gap: 6px;
		    font-size: 15px;
		}
		
		.label {
			padding-bottom: 10px;
		}
    </style>
</head>
<body>

<div class="navbar-top">
    <div class="brand"><a href="${pageContext.request.contextPath}">Projekat</a></div>

    <div class="nav-links">
        <a href="${pageContext.request.contextPath}/login">Prijavi se</a>
    </div>
</div>

<div class="page-wrapper">
    <div class="register-container">
        <h2>Registracija</h2>

        <form method="post" action="${pageContext.request.contextPath}/register">
            <input type="text" name="username" placeholder="Korisnicko ime" required />
            <input type="email" name="email" placeholder="Email adresa" required />
            <input type="password" name="password" placeholder="Lozinka" required />
            <div class="radio">
			    <label class="radio-option">
			        <input type="radio" name="uloga" value="1" required>
			        <div class="label">Admin</div>
			    </label>
			
			    <label class="radio-option">
			        <input type="radio" name="uloga" value="2" required>
			        <div class="label">Korisnik</div>
			    </label>
			</div>

            <button type="submit">Registruj se</button>
        </form>
    </div>
</div>

</body>
</html>
