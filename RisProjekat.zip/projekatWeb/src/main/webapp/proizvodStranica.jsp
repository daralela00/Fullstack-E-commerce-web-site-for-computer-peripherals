<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>


<!DOCTYPE html>
<html>
<head>
<title>Projekat - Detalji proizvoda</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link
	href="https://fonts.googleapis.com/css2?family=Bitcount+Single:wght@100..900&display=swap"
	rel="stylesheet">

<style>
body {
	margin: 0;
	font-family: Arial, sans-serif;
	background-color: rgb(236, 236, 234);
}

.navbar-top {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 15px 40px;
	background-color: #111;
	color: white;
}

.navbar-left {
	display: flex;
	align-items: center;
}

.navbar-right {
	display: flex;
	align-items: center;
}

.brand {
	font-family: "Bitcount Single", system-ui;
	font-weight: 300;
	font-size: 40px;
}

.brand a {
	text-decoration: none;
	color: white;
}

.dropdown {
	position: relative;
	display: inline-block;
	margin-left: 50px;
}

.dropdown-button {
	background: none;
	border: none;
	color: white;
	font-size: 16px;
	cursor: pointer;
	padding: 5px 10px;
}

.dropdown-content {
	display: none;
	position: absolute;
	background-color: #333;
	min-width: 160px;
	z-index: 10;
	top: 100%;
}

.dropdown-content a {
	color: white;
	padding: 12px 16px;
	text-decoration: none;
	display: block;
	white-space: nowrap;
}

.dropdown-content a:hover {
	background-color: #555;
}

.dropdown:hover .dropdown-content {
	display: block;
}

.cart-dropdown {
	position: relative;
	display: inline-block;
	margin-left: 20px;
	margin-right: 20px;
}

.cart-icon {
	cursor: pointer;
	display: flex;
	align-items: center;
}

.cart-icon img {
	width: 28px;
	height: 28px;
}

.cart-content {
	display: none;
	position: absolute;
	right: 0;
	top: 100%;
	background-color: #333;
	min-width: 280px;
	color: white;
	border-radius: 6px;
	padding: 10px;
	z-index: 100;
}

.cart-dropdown:hover .cart-content {
	display: block;
}

.cart-item {
	display: flex;
	justify-content: space-between;
	font-size: 14px;
	padding: 6px 0;
	border-bottom: 1px solid #555;
}

.cart-actions {
	margin-top: 10px;
	text-align: center;
}

.cart-actions a {
	margin: 5px;
	display: inline-block;
	background-color: #28a745;
	color: white;
	text-decoration: none;
	padding: 8px 15px;
	border-radius: 6px;
	font-weight: bold;
}

.nav-links a {
	color: white;
	text-decoration: none;
	margin-left: 20px;
}

.nav-links a:hover {
	text-decoration: underline;
}

h3 {
	margin: 5px 0;
}

.content {
	padding: 40px;
}

.product-details-container {
	display: flex;
	gap: 40px;
}

.product-left {
	flex: 2;
	background-color: #fff;
	padding: 20px;
	border-radius: 8px;
}

.product-right {
	flex: 1;
	background-color: #fff;
	padding: 20px;
	border-radius: 8px;
	height: fit-content;
}

.product-image {
	width: 100%;
	max-height: 400px;
	object-fit: contain;
	margin-bottom: 20px;
}

.add-to-cart-btn {
	display: inline-block;
	background-color: #28a745;
	color: white;
	padding: 12px 20px;
	border-radius: 6px;
	text-decoration: none;
	font-weight: bold;
}

.add-to-cart-btn:hover {
	background-color: #218838;
}

.review {
	border-bottom: 1px solid #ddd;
	padding: 10px 0;
}

.delete-button {
	background-color: #dc3545;
	color: white;
	padding: 8px 15px;
	border: none;
	border-radius: 5px;
	font-weight: bold;
	cursor: pointer;
	text-decoration: none;
	display: inline-block;
}
</style>
</head>

<body>

	<div class="navbar-top">
		<div class="navbar-left">
			<div class="brand">
				<a href="${pageContext.request.contextPath}">Projekat</a>
			</div>

			<c:if test="${not empty sessionScope.ulogovaniKorisnik}">
				<span style="margin-left: 40px; color: white; font-size: 16px;">
					<b>${sessionScope.ulogovaniKorisnik.username}</b>
				</span>
			</c:if>

			<div class="dropdown">
				<button class="dropdown-button">Kategorije</button>
				<div class="dropdown-content">
					<c:forEach var="kat" items="${kategorije}">
						<a
							href="${pageContext.request.contextPath}/kategorija/${kat.idKategorije}">
							${kat.naziv} </a>
					</c:forEach>
				</div>
			</div>
		</div>

		<div class="navbar-right">

			<c:if test="${not empty sessionScope.ulogovaniKorisnik and sessionScope.ulogovaniKorisnik.dm64924Uloge.idUloge == 2}">
				<div class="cart-dropdown">
					<div class="cart-icon">
						<img
							src="${pageContext.request.contextPath}/images/whiteshopcart.png">
						Korpa (${not empty sessionScope.korpa ? sessionScope.korpa.size() : 0})
					</div>

					<div class="cart-content">
						<c:choose>
							<c:when test="${not empty sessionScope.korpa}">
								<c:set var="ukupnaCena" value="0" />

								<c:forEach var="entry" items="${sessionScope.korpa}">
									<c:set var="p" value="${proizvodiMap[entry.key]}" />
									<c:set var="stavkaCena" value="${p.cena.multiply(entry.value)}" />

									<div class="cart-item">
										<span>${p.naziv}</span> <span> ${entry.value} x
											${p.cena} RSD = ${stavkaCena} RSD </span>
									</div>

									<c:set var="ukupnaCena" value="${ukupnaCena + stavkaCena}" />
								</c:forEach>

								<div class="cart-total">Ukupno: ${ukupnaCena} RSD</div>

								<div class="cart-actions">
									<a href="${pageContext.request.contextPath}/korpa/potvrdi">
										Potvrdi narudzbinu </a> <a
										href="${pageContext.request.contextPath}/korpa/ocisti/${proizvod.idProizvodi}/nacin2"
										style="background-color: #dc3545;"> Ocisti korpu </a>
								</div>
							</c:when>

							<c:otherwise>
								<div class="cart-empty">Korpa je prazna</div>
							</c:otherwise>
						</c:choose>
					</div>
				</div>
			</c:if>

			<div class="nav-links">
				<c:choose>
					<c:when test="${empty sessionScope.ulogovaniKorisnik}">
						<a href="${pageContext.request.contextPath}/login">Prijavi se</a>
						<a href="${pageContext.request.contextPath}/register">Registruj
							se</a>
					</c:when>
					<c:otherwise>
						<a href="${pageContext.request.contextPath}/logout">Odjavi se</a>
					</c:otherwise>
				</c:choose>
			</div>

		</div>
	</div>


	<div class="content">

		<div class="product-details-container">

			<div class="product-left">


				<c:if test="${not empty proizvod.dm64924Slikeproizvodas}">
					<img class="product-image"
						src="${pageContext.request.contextPath}${proizvod.dm64924Slikeproizvodas[0].urlSlike}"
						alt="${proizvod.naziv}">
				</c:if>


				<h3>Opis proizvoda</h3>
				<p>${proizvod.opis}</p>

				<h3>Prosecna ocena</h3>
				<p>${prosecnaOcena}/5 &#127775</p>



				<h3 style="border-bottom: 1px solid #ddd;">Recenzije</h3>

				<c:choose>
					<c:when test="${empty recenzije}">
						<p>Nema recenzija za ovaj proizvod.</p>
					</c:when>
					<c:otherwise>
						<c:forEach var="r" items="${recenzije}">
							<div class="review">
								<strong>${r.dm64924Korisnici.username}</strong> <span
									style="color: #777; font-size: 13px;"> • <fmt:formatDate
										value="${r.datum}" pattern="dd.MM.yyyy HH:mm" />
								</span>
								<div>Ocena: ${r.ocena}/5 &#127775</div>
								<p>${r.komentar}</p>
							</div>
						</c:forEach>
					</c:otherwise>
				</c:choose>

				<c:if test="${not empty sessionScope.ulogovaniKorisnik  and sessionScope.ulogovaniKorisnik.dm64924Uloge.idUloge == 2}">
					<br>
					<br>
					<h3>Ostavite vasu recenziju proizvoda</h3>

					<form action="${pageContext.request.contextPath}/recenzija/dodaj"
						method="post" style="margin-top: 10px;">
						<input type="hidden" name="idProizvoda"
							value="${proizvod.idProizvodi}" /> <label for="ocena">Ocena:</label>
						<select name="ocena" id="ocena" required
							style="margin-left: 10px; margin-bottom: 10px;">
							<option value="1">1</option>
							<option value="2">2</option>
							<option value="3">3</option>
							<option value="4">4</option>
							<option value="5">5</option>
						</select> <br /> <label for="komentar">Komentar:</label><br />
						<textarea name="komentar" id="komentar" rows="4" cols="30"
							placeholder="Unesite komentar..." required
							style="margin-bottom: 10px;"></textarea>

						<br />
						<button type="submit"
							style="background-color: #007bff; color: white; padding: 8px 15px; border: none; border-radius: 5px; font-weight: bold; cursor: pointer;">
							Dodaj recenziju</button>
					</form>
				</c:if>

				<c:if test="${not empty sessionScope.ulogovaniKorisnik  and sessionScope.ulogovaniKorisnik.dm64924Uloge.idUloge == 2}">

					<form
						action="${pageContext.request.contextPath}/proizvod/${proizvod.idProizvodi}/obrisiRecenziju"
						method="post" style="margin-top: 10px; display: inline-block;">
						<button type="submit" class="delete-button">Obrisi moju
							recenziju</button>
					</form>

				</c:if>

				<c:if test="${not empty error}">
					<div
						style="background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 6px; margin-bottom: 20px;">
						${error}</div>
				</c:if>

				<c:if test="${not empty success}">
					<div
						style="background-color: #d4edda; color: #155724; padding: 10px; border-radius: 6px; margin-bottom: 20px;">
						${success}</div>
				</c:if>
			</div>


			<div class="product-right">

				<c:choose>
					<c:when test="${proizvod.lager gt 0}">
						<h2>${proizvod.naziv}</h2>
						<div style="font-size: 20px; font-weight: bold; color: black;">Cena:</div>
						<div
							style="font-size: 24px; font-weight: bold; color: green; margin-bottom: 20px;">${proizvod.cena}
							RSD</div>
						<c:if test="${not empty sessionScope.ulogovaniKorisnik  and sessionScope.ulogovaniKorisnik.dm64924Uloge.idUloge == 2}">
							<a class="add-to-cart-btn"
								href="${pageContext.request.contextPath}/korpa/dodaj/${proizvod.idProizvodi}/nacin2">
								Dodaj u korpu </a>
						</c:if>
					</c:when>
					<c:otherwise>
						<h2>${proizvod.naziv}</h2>
						<div style="font-size: 20px; font-weight: bold; color: black;">Cena:</div>
						<div
							style="font-size: 24px; font-weight: bold; color: red; margin-bottom: 20px;">${proizvod.cena}
							RSD</div>
						<div style="font-size: 24px; font-weight: bold; color: red;">Trenutno
							nedostupan</div>
					</c:otherwise>
				</c:choose>



			</div>

		</div>
	</div>

</body>
</html>
