<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<title>Prodavnica Projekat</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link
	href="https://fonts.googleapis.com/css2?family=Bitcount+Single:wght@100..900&display=swap"
	rel="stylesheet">

<style>
body {
	margin: 0;
	font-family: Arial, sans-serif;
	background-color: rgb(236, 236, 234);
}

.navbar-top {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 15px 40px;
	background-color: #111;
	color: white;
}

.navbar-left {
	display: flex;
	align-items: center;
}

.navbar-right {
	display: flex;
	align-items: center;
}

.brand {
	font-family: "Bitcount Single", system-ui;
	font-optical-sizing: auto;
	font-weight: 300;
	font-size: 40px;
	font-style: normal;
	font-variation-settings: "slnt" 0, "CRSV" 0.5, "ELSH" 0, "ELXP" 0;
}

.brand a {
	text-decoration: none;
	color: white;
}

.cart-dropdown {
	position: relative;
	display: inline-block;
	margin-left: 20px;
	margin-right: 20px;
}

.cart-icon {
	cursor: pointer;
	display: flex;
	align-items: center;
}

.cart-icon img {
	width: 28px;
	height: 28px;
}

.cart-content {
	display: none;
	position: absolute;
	right: 0;
	top: 100%;
	background-color: #333;
	min-width: 280px;
	color: white;
	border-radius: 6px;
	padding: 10px;
	z-index: 100;
}

.cart-dropdown:hover .cart-content {
	display: block;
}

.cart-item {
	display: flex;
	justify-content: space-between;
	font-size: 14px;
	padding: 6px 0;
	border-bottom: 1px solid #555;
}

.cart-item:last-child {
	border-bottom: none;
}

.cart-empty {
	font-size: 14px;
	text-align: center;
	padding: 10px;
	color: #ccc;
}

.cart-actions {
	margin-top: 10px;
	text-align: center;
}

.cart-actions a {
	margin: 5px;
	display: inline-block;
	background-color: #28a745;
	color: white;
	text-decoration: none;
	padding: 8px 15px;
	border-radius: 6px;
	font-weight: bold;
	transition: background-color 0.3s, transform 0.2s;
}

.cart-actions a:hover {
	background-color: #218838;
	transform: scale(1.05);
}

.nav-links a {
	color: white;
	text-decoration: none;
	margin-left: 20px;
	font-size: 16px;
}

.nav-links a:hover {
	text-decoration: underline;
}

.dropdown {
	position: relative;
	display: inline-block;
	margin-left: 50px;
}

.dropdown-button {
	background: none;
	border: none;
	color: white;
	font-size: 16px;
	cursor: pointer;
	padding: 5px 10px;
}

.dropdown-content {
	display: none;
	position: absolute;
	background-color: #333;
	min-width: 160px;
	z-index: 10;
	top: 100%;
}

.dropdown-content a {
	color: white;
	padding: 12px 16px;
	text-decoration: none;
	display: block;
	white-space: nowrap;
}

.dropdown-content a:hover {
	background-color: #555;
}

.dropdown:hover .dropdown-content {
	display: block;
}

.content {
	padding: 40px;
}

.page-title {
	font-size: 26px;
	font-weight: 500;
}

.products-container {
	display: flex;
	flex-wrap: wrap;
	gap: 30px;
	padding: 20px 0;
}

.product-card {
	display: flex;
	flex-direction: column;
	justify-content: space-between;
	height: 350px;
	width: 200px;
	padding: 8px;
	border: 1px solid #ccc;
	border-radius: 8px;
	background-color: #fff;
	text-align: center;
}

.product-card img {
	width: 100%;
	height: 200px;
	object-fit: cover;
}

.product-card h3 {
	font-size: 16px;
	margin: 10px 0 5px;
}

.product-card p {
	margin: 5px 0;
	font-size: 14px;
}

.product-card .price1 {
	font-weight: bold;
	color: green;
	margin-top: 5px;
}

.product-card .price2 {
	font-weight: bold;
	color: red;
	margin-top: 5px;
}

.product-card img.add-to-cart {
	width: 40px;
	height: 40px;
	object-fit: contain;
}

.product-card img.add-to-cart:hover {
	transform: scale(1.1);
}

.product-card-link {
	text-decoration: none;
	color: inherit;
}

.add-to-cart {
	cursor: pointer;
	margin-left: 10px;
}

.add-to-cart.disabled {
	cursor: not-allowed;
	opacity: 0.6;
}

.error-message {
	background-color: #ffe5e5;
	color: #b30000;
	border: 1px solid #ffb3b3;
	padding: 12px 15px;
	border-radius: 6px;
	font-size: 14px;
	text-align: center;
	margin-bottom: 15px;
}

.success-message {
	background-color: #e6ffed;
	color: #1e7e34;
	border: 1px solid #b3e6c1;
	padding: 12px 15px;
	border-radius: 6px;
	font-size: 14px;
	text-align: center;
	margin-bottom: 15px;
}
</style>
</head>
<body>

	<div class="navbar-top">
		<div class="navbar-left">
			<div class="brand">
				<a href="${pageContext.request.contextPath}">Projekat</a>
			</div>

			<c:if test="${not empty sessionScope.ulogovaniKorisnik}">
				<span style="margin-left: 40px; color: white; font-size: 16px;">
					<b>${sessionScope.ulogovaniKorisnik.username}</b>
				</span>
			</c:if>

			<div class="dropdown">
				<button class="dropdown-button">Kategorije</button>
				<div class="dropdown-content">
					<c:forEach var="kat" items="${kategorije}">
						<a
							href="${pageContext.request.contextPath}/kategorija/${kat.idKategorije}">${kat.naziv}</a>
					</c:forEach>
				</div>
			</div>

			<c:if
				test="${not empty sessionScope.ulogovaniKorisnik and sessionScope.ulogovaniKorisnik.dm64924Uloge.idUloge == 1}">
					<div class="dropdown">
						<button class="dropdown-button">Modifikacija kategorije</button>
						<div class="dropdown-content">
							<a href="${pageContext.request.contextPath}/dodavanjeKategorije">Dodavanje </a>
							<a href="${pageContext.request.contextPath}/brisanjeKategorije">Brisanje</a>
							<a href="${pageContext.request.contextPath}/izmenaKategorije">Izmena</a>
						</div>
					</div>
					
					<div class="dropdown">
						<button class="dropdown-button">Modifikacija proizvoda</button>
						<div class="dropdown-content">
							<a href="${pageContext.request.contextPath}/dodavanjeProizvoda">Dodavanje</a>
							<a href="${pageContext.request.contextPath}/brisanjeProizvoda">Brisanje</a>
							<a href="${pageContext.request.contextPath}/izmenaProizvoda">Izmena</a>
						</div>
					</div>
					
					<div class="dropdown">
						<button class="dropdown-button">Izvestaji</button>
						<div class="dropdown-content">
							<a href="${pageContext.request.contextPath}/spisakSvihKorisnika.pdf">Spisak svih korisnika</a>
							<a href="${pageContext.request.contextPath}/spisakNarudzbina">Spisak narudzbina</a>
							<a href="${pageContext.request.contextPath}/spisakStavkiNarudzbine">Spisak stavki narudzbine</a>
						</div>
					</div>
			</c:if>
		</div>
		<div class="navbar-right">

			<c:if
				test="${not empty sessionScope.ulogovaniKorisnik  and sessionScope.ulogovaniKorisnik.dm64924Uloge.idUloge == 2}">
				<div class="cart-dropdown">
					<div class="cart-icon">
						<img
							src="${pageContext.request.contextPath}/images/whiteshopcart.png"
							alt="Korpa"> Korpa (${not empty sessionScope.korpa ? sessionScope.korpa.size() : 0})
					</div>

					<div class="cart-content">
						<c:choose>
							<c:when test="${not empty sessionScope.korpa}">
								<c:set var="ukupnaCena" value="0" />
								<c:forEach var="entry" items="${sessionScope.korpa}">
									<c:set var="proizvod" value="${proizvodiMap[entry.key]}" />
									<c:set var="stavkaCena"
										value="${proizvod.cena.multiply(entry.value)}" />
									<div class="cart-item">
										<span>${proizvod.naziv}</span> <span>${entry.value} x
											${proizvod.cena} RSD = ${stavkaCena} RSD</span>
									</div>
									<c:set var="ukupnaCena" value="${ukupnaCena + stavkaCena}" />
								</c:forEach>

								<div class="cart-total">Ukupno: ${ukupnaCena} RSD</div>

								<div class="cart-actions">
									<a href="${pageContext.request.contextPath}/korpa/potvrdi">
										Potvrdi narudzbinu </a> <a
										href="${pageContext.request.contextPath}/korpa/ocisti/nacin1"
										style="background-color: #dc3545;"
										onmouseover="this.style.backgroundColor='#c82333';"
										onmouseout="this.style.backgroundColor='#dc3545';"> Ocisti
										korpu </a>
								</div>
							</c:when>

							<c:otherwise>
								<div class="cart-empty">Korpa je prazna</div>
							</c:otherwise>
						</c:choose>
					</div>
				</div>
			</c:if>

			<div class="nav-links">

				<c:choose>
					<c:when test="${empty sessionScope.ulogovaniKorisnik}">
						<a href="${pageContext.request.contextPath}/login">Prijavi se</a>
						<a href="${pageContext.request.contextPath}/register">Registruj
							se</a>
					</c:when>

					<c:otherwise>
						<a href="${pageContext.request.contextPath}/logout">Odjavi se</a>
					</c:otherwise>
				</c:choose>

			</div>
		</div>
	</div>

	<div class="content">

		<c:if test="${not empty error}">
				<div class="error-message">${error}</div>
			</c:if>
			
			<c:if test="${not empty success}">
				<div class="success-message">${success}</div>
			</c:if>

		<h2 class="page-title">

			<c:choose>
				<c:when test="${not empty kategorija}">
                ${kategorija.naziv}
            </c:when>
				<c:otherwise>
                Izaberite neku od kategorija kako biste videli proizvode...
            </c:otherwise>
			</c:choose>
		</h2>

		<c:if test="${not empty proizvodi}">
			<div class="products-container">
				<c:forEach var="pro" items="${proizvodi}">
					<div class="product-card">
						<a class="product-card-link"
							href="${pageContext.request.contextPath}/proizvod/${pro.idProizvodi}">
							<c:choose>
								<c:when test="${not empty pro.dm64924Slikeproizvodas}">
									<img
										src="${pageContext.request.contextPath}${pro.dm64924Slikeproizvodas[0].urlSlike}"
										alt="${pro.naziv}" />
								</c:when>
								<c:otherwise>
									<img src="/images/default.jpg" alt="No image" />
								</c:otherwise>
							</c:choose>
							<h3>${pro.naziv}</h3>
						</a> <br>
						<c:choose>
							<c:when test="${pro.lager gt 0}">
								<div
									style="display: flex; align-items: center; justify-content: center;">
									<p class="price1" style="margin: 0;">
										${pro.cena} RSD <br> Trenutno dostupan
									</p>

									<c:if
										test="${not empty sessionScope.ulogovaniKorisnik and sessionScope.ulogovaniKorisnik.dm64924Uloge.idUloge == 2}">
										<a
											href="${pageContext.request.contextPath}/korpa/dodaj/${pro.idProizvodi}/nacin1">
											<img
											src="${pageContext.request.contextPath}/images/shopcart.png"
											class="add-to-cart" alt="Dodaj u korpu" />
										</a>
									</c:if>
								</div>
							</c:when>

							<c:otherwise>
								<div
									style="display: flex; align-items: center; justify-content: center;">
									<p class="price2" style="margin: 0;">
										${pro.cena} RSD <br> Trenutno nedostupan
									</p>

									<c:if
										test="${not empty sessionScope.ulogovaniKorisnik and sessionScope.ulogovaniKorisnik.dm64924Uloge.idUloge == 2}">
										<img
											src="${pageContext.request.contextPath}/images/shopcart.png"
											class="add-to-cart disabled" alt="Nedostupno" />
									</c:if>
								</div>
							</c:otherwise>
						</c:choose>
					</div>
				</c:forEach>
			</div>
		</c:if>
	</div>

</body>
</html>