<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bitcount+Single:wght@100..900&display=swap" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: rgb(236, 236, 234);
        }

        .navbar-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 40px;
            background-color: #111;
            color: white;
        }

        .brand {
            font-family: "Bitcount Single", system-ui;
            font-weight: 300;
            font-size: 40px;
        }

        .brand a{
            text-decoration: none;
            color: white;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-size: 16px;
        }

        .nav-links a:hover {
            text-decoration: underline;
        }

        .page-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100vh - 80px);
        }

        .login-container {
            background-color: white;
            padding: 35px 40px;
            width: 360px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 25px;
            margin-top: 0px;
        }

        .login-container input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            font-size: 15px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        .login-container button {
            width: 100%;
            padding: 10px;
            background-color: #111;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }
        
        .login-container input,
        .login-container button {
            box-sizing: border-box;
        }

        .login-container button:hover {
            background-color: #333;
        }

        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }

    </style>
</head>
<body>

<div class="navbar-top">
    <div class="brand"><a href="${pageContext.request.contextPath}">Projekat</a></div>

    <div class="nav-links">
        <a href="${pageContext.request.contextPath}/register">Registruj se</a>
    </div>
</div>

<div class="page-wrapper">
    <div class="login-container">
        <h2>Prijava</h2>

        <c:if test="${not empty error}">
            <div class="error-message">${error}</div>
        </c:if>

        <form method="post" action="${pageContext.request.contextPath}/login">
            <input type="text" name="username" placeholder="Korisničko ime" required />
            <input type="password" name="password" placeholder="Lozinka" required />
            <button type="submit">Prijavi se</button>
        </form>
    </div>
</div>

</body>
</html>
