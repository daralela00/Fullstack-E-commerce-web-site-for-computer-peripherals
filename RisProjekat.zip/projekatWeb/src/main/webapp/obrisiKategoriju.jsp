<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<title>Login</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link
	href="https://fonts.googleapis.com/css2?family=Bitcount+Single:wght@100..900&display=swap"
	rel="stylesheet">

<style>
body {
	margin: 0;
	font-family: Arial, sans-serif;
	background-color: rgb(236, 236, 234);
}

.navbar-top {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 15px 40px;
	background-color: #111;
	color: white;
}

.navbar-left {
	display: flex;
	align-items: center;
}

.navbar-right {
	display: flex;
	align-items: center;
}

.brand {
	font-family: "Bitcount Single", system-ui;
	font-weight: 300;
	font-size: 40px;
}

.brand a {
	text-decoration: none;
	color: white;
}

.dropdown {
	position: relative;
	display: inline-block;
	margin-left: 50px;
}

.dropdown-button {
	background: none;
	border: none;
	color: white;
	font-size: 16px;
	cursor: pointer;
	padding: 5px 10px;
}

.dropdown-content {
	display: none;
	position: absolute;
	background-color: #333;
	min-width: 160px;
	z-index: 10;
	top: 100%;
}

.dropdown-content a {
	color: white;
	padding: 12px 16px;
	text-decoration: none;
	display: block;
	white-space: nowrap;
}

.dropdown-content a:hover {
	background-color: #555;
}

.dropdown:hover .dropdown-content {
	display: block;
}

.nav-links a {
	color: white;
	text-decoration: none;
	margin-left: 20px;
	font-size: 16px;
}

.nav-links a:hover {
	text-decoration: underline;
}

.page-wrapper {
	display: flex;
	justify-content: center;
	align-items: center;
	height: calc(100vh - 80px);
}

.login-container {
	background-color: white;
	padding: 35px 40px;
	width: 360px;
	border-radius: 12px;
	box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
}

.login-container h2 {
	text-align: center;
	margin-bottom: 25px;
	margin-top: 0px;
}

.login-container input {
	width: 100%;
	padding: 10px;
	margin-bottom: 15px;
	font-size: 15px;
	border-radius: 6px;
	border: 1px solid #ccc;
}

.login-container button {
	width: 100%;
	padding: 10px;
	background-color: #111;
	color: white;
	border: none;
	border-radius: 6px;
	font-size: 16px;
	cursor: pointer;
}

.login-container input, .login-container button {
	box-sizing: border-box;
}

.login-container button:hover {
	background-color: #333;
}

.error-message {
	background-color: #ffe5e5;
	color: #b30000;
	border: 1px solid #ffb3b3;
	padding: 12px 15px;
	border-radius: 6px;
	font-size: 14px;
	text-align: center;
	margin-bottom: 15px;
}

.success-message {
	background-color: #e6ffed;
	color: #1e7e34;
	border: 1px solid #b3e6c1;
	padding: 12px 15px;
	border-radius: 6px;
	font-size: 14px;
	text-align: center;
	margin-bottom: 15px;
}
</style>
</head>
<body>

	<div class="navbar-top">
		<div class="navbar-left">
			<div class="brand">
				<a href="${pageContext.request.contextPath}">Projekat</a>
			</div>

			<c:if test="${not empty sessionScope.ulogovaniKorisnik}">
				<span style="margin-left: 40px; color: white; font-size: 16px;">
					<b>${sessionScope.ulogovaniKorisnik.username}</b>
				</span>
			</c:if>

			<div class="dropdown">
				<button class="dropdown-button">Kategorije</button>
				<div class="dropdown-content">
					<c:forEach var="kat" items="${kategorije}">
						<a
							href="${pageContext.request.contextPath}/kategorija/${kat.idKategorije}">${kat.naziv}</a>
					</c:forEach>
				</div>
			</div>

			<c:if
				test="${not empty sessionScope.ulogovaniKorisnik and sessionScope.ulogovaniKorisnik.dm64924Uloge.idUloge == 1}">
				<div class="dropdown">
					<button class="dropdown-button">Modifikacija kategorije</button>
					<div class="dropdown-content">
						<a href="${pageContext.request.contextPath}/dodavanjeKategorije">Dodavanje</a>
						<a href="${pageContext.request.contextPath}/brisanjeKategorije">Brisanje</a>
						<a href="${pageContext.request.contextPath}/izmenaKategorije">Izmena</a>
					</div>
				</div>

				<div class="dropdown">
					<button class="dropdown-button">Modifikacija proizvoda</button>
					<div class="dropdown-content">
						<a href="${pageContext.request.contextPath}/dodavanjeProizvoda">Dodavanje</a>
						<a href="${pageContext.request.contextPath}/brisanjeProizvoda">Brisanje</a>
						<a href="${pageContext.request.contextPath}/izmenaProizvoda">Izmena</a>
					</div>
				</div>
				
				<div class="dropdown">
						<button class="dropdown-button">Izvestaji</button>
						<div class="dropdown-content">
							<a href="${pageContext.request.contextPath}/spisakSvihKorisnika.pdf">Spisak svih korisnika</a>
							<a href="${pageContext.request.contextPath}/spisakNarudzbina">Spisak narudzbina</a>
							<a href="${pageContext.request.contextPath}/spisakStavkiNarudzbine">Spisak stavki narudzbine</a>
						</div>
				</div>
			</c:if>
		</div>

		<div class="navbar-right">

			<div class="nav-links">
				<a href="${pageContext.request.contextPath}/logout">Odjavi se</a>
			</div>

		</div>
	</div>

	<div class="page-wrapper">
		<div class="login-container">
			<h2>Brisanje kategorije</h2>



			<form method="post"
				action="${pageContext.request.contextPath}/brisanjeKategorije">
				<select name="idKategorije" required
					style="width: 100%; padding: 10px; margin-bottom: 15px; border-radius: 6px;">
					<option value="">--- Izaberi kategoriju ---</option>

					<c:forEach var="kat" items="${kategorije}">
						<option value="${kat.idKategorije}">${kat.naziv}</option>
					</c:forEach>
				</select>
				<button type="submit">Obrisi kategoriju</button>
			</form>

			<c:if test="${not empty error}">
				<div class="error-message">${error}</div>
			</c:if>

			<c:if test="${not empty success}">
				<div class="success-message">${success}</div>
			</c:if>
		</div>
	</div>

</body>
</html>
