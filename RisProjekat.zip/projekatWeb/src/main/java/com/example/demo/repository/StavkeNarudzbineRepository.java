package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import bazaJPA.Dm64924Stavkenarudzbine;

public interface StavkeNarudzbineRepository extends JpaRepository<Dm64924Stavkenarudzbine, Integer>{
	@Query("SELECT s FROM Dm64924Stavkenarudzbine s WHERE s.dm64924Narudzbine.idNarudzbine = :idNarudzbine")
	public List<Dm64924Stavkenarudzbine> stavkeNarudzbine(@Param("idNarudzbine") int idNarudzbine);
}
