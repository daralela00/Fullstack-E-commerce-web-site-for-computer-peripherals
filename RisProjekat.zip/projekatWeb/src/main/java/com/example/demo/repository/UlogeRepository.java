package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import bazaJPA.Dm64924Uloge;

public interface UlogeRepository extends JpaRepository<Dm64924Uloge, Integer>{

}
