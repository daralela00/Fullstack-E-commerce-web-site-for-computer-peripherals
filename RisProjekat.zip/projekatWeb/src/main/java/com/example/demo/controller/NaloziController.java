package com.example.demo.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.repository.NaloziRepository;
import com.example.demo.repository.NarudzbineRepository;
import com.example.demo.repository.ProizvodRepository;
import com.example.demo.repository.StavkeNarudzbineRepository;
import com.example.demo.repository.UlogeRepository;

import bazaJPA.Dm64924Korisnici;
import bazaJPA.Dm64924Narudzbine;
import bazaJPA.Dm64924Proizvodi;
import bazaJPA.Dm64924Stavkenarudzbine;
import bazaJPA.Dm64924Uloge;
import jakarta.servlet.http.HttpSession;

@Controller
public class NaloziController {
	
	private final NaloziRepository naloziRepository;
	private final UlogeRepository ulogeRepository;
	private final PasswordEncoder passwordEncoder;
	private final ProizvodRepository proizvodRepository;
	private final NarudzbineRepository narudzbineRepository;
	private final StavkeNarudzbineRepository stavkeNarudzbineRepository;
	
	
	public NaloziController(NaloziRepository naloziRepository,
							UlogeRepository ulogeRepository,
							PasswordEncoder passwordEncoder,
							ProizvodRepository proizvodRepository,
							NarudzbineRepository narudzbineRepository,
							StavkeNarudzbineRepository stavkeNarudzbineRepository) {
		this.naloziRepository = naloziRepository;
		this.ulogeRepository = ulogeRepository;
		this.passwordEncoder = passwordEncoder;
		this.proizvodRepository = proizvodRepository;
		this.narudzbineRepository = narudzbineRepository;
		this.stavkeNarudzbineRepository = stavkeNarudzbineRepository;
	}

	@GetMapping("/register")
	public String registerPage(Model model) {
		
		return "register";
	}
	
	@PostMapping("/register")
	public String registerUser(
			@RequestParam String username,
			@RequestParam String email,
			@RequestParam String password,
			@RequestParam int uloga,
			Model model
			) {
		
		if (naloziRepository.existsByUsername(username)) {
			model.addAttribute("error", "Korisnicko ime vec postoji!");
			return "register";
		}
		
		if (naloziRepository.existsByEmail(email)) {
			model.addAttribute("error", "Email vec postoji!");
		}
		
		Dm64924Uloge ulogaKorisnika = ulogeRepository.findById(uloga)
		        .orElseThrow(() -> new RuntimeException("Uloga ne postoji"));
		
		Dm64924Korisnici korisnik = new Dm64924Korisnici();
		korisnik.setUsername(username);
		korisnik.setEmail(email);
		korisnik.setPassword(passwordEncoder.encode(password));
		korisnik.setDm64924Uloge(ulogaKorisnika);
		korisnik.setKreiran(new Date());	
		naloziRepository.save(korisnik);
		
		return "redirect:/login";
	}
	
	@GetMapping("/login")
	public String loginPage(Model model) {
		return "login";
	}
	
	@PostMapping("/login")
	public String loginUser(
			@RequestParam String username,
			@RequestParam String password,
			HttpSession session,
			Model model
			) {
		
		Dm64924Korisnici korisnik = naloziRepository.findByUsername(username).orElse(null);
		
		if (korisnik != null && passwordEncoder.matches(password, korisnik.getPassword())) {

			session.setAttribute("ulogovaniKorisnik", korisnik);
			
			return "redirect:/";
			
		} else {
			model.addAttribute("error", "Pogrešno korisničko ime ili lozinka!");
			return "login";
		}
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/login";
	}
	
	@GetMapping("/korpa/dodaj/{idProizvodi}/nacin1")
	public String dodajUKorpu1(@PathVariable int idProizvodi, HttpSession session) {
	    Map<Integer, Integer> korpa = (Map<Integer, Integer>) session.getAttribute("korpa");
	    if (korpa == null) {
	        korpa = new HashMap<>();
	    }
	    korpa.put(idProizvodi, korpa.getOrDefault(idProizvodi, 0) + 1);
	    session.setAttribute("korpa", korpa);
	    return "redirect:/";
	}
	
	@GetMapping("/korpa/dodaj/{idProizvodi}/nacin2")
	public String dodajUKorpu2(@PathVariable int idProizvodi, HttpSession session) {
	    Map<Integer, Integer> korpa = (Map<Integer, Integer>) session.getAttribute("korpa");
	    if (korpa == null) {
	        korpa = new HashMap<>();
	    }
	    korpa.put(idProizvodi, korpa.getOrDefault(idProizvodi, 0) + 1);
	    session.setAttribute("korpa", korpa);
	    return "redirect:/proizvod/" + Integer.toString(idProizvodi);
	}
	
	@GetMapping("/korpa/potvrdi")
	public String potvrdiNarudzbinu(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
	    Dm64924Korisnici korisnik = (Dm64924Korisnici) session.getAttribute("ulogovaniKorisnik");
	    Map<Integer, Integer> korpa = (Map<Integer, Integer>) session.getAttribute("korpa");

	    if (korpa == null || korpa.isEmpty()) {
	        model.addAttribute("poruka", "Korpa je prazna!");
	        return "redirect:/";
	    }

	    Dm64924Narudzbine narudzbina = new Dm64924Narudzbine();
	    narudzbina.setDm64924Korisnici(korisnik);
	    narudzbina.setDatum(new Date());

	    BigDecimal ukupnaCena = BigDecimal.ZERO;
	    List<Dm64924Stavkenarudzbine> stavke = new ArrayList<>();

	    for (Map.Entry<Integer, Integer> entry : korpa.entrySet()) {
	        int idProizvoda = entry.getKey();
	        int kolicina = entry.getValue();
	        
	        Map<Integer, Dm64924Proizvodi> proizvodiMap = (Map<Integer, Dm64924Proizvodi>) session.getAttribute("proizvodiMap");
	        Dm64924Proizvodi proizvod = proizvodiMap.get(idProizvoda);

	        if (proizvod == null) {
	            continue;
	        }

	        if (proizvod.getLager() < kolicina) {

	        	redirectAttributes.addFlashAttribute("error",
	                "Nema dovoljno proizvoda na lageru: " + proizvod.getNaziv() +
	                ". Dostupno: " + proizvod.getLager() +
	                ", traženo: " + kolicina);
	            return "redirect:/";
	        }

	        BigDecimal cenaStavke = proizvod.getCena().multiply(BigDecimal.valueOf(kolicina));

	        Dm64924Stavkenarudzbine stavka = new Dm64924Stavkenarudzbine();
	        stavka.setDm64924Proizvodi(proizvod);
	        stavka.setKolicina(kolicina);
	        stavka.setCena(cenaStavke);
	        stavka.setDm64924Narudzbine(narudzbina);

	        stavke.add(stavka);

	        ukupnaCena = ukupnaCena.add(cenaStavke);

	        proizvod.setLager(proizvod.getLager() - kolicina);
	        proizvodRepository.save(proizvod);
	    }

	    narudzbina.setUkupnaCena(ukupnaCena);
	    narudzbina.setDm64924Stavkenarudzbines(stavke);

	    narudzbineRepository.save(narudzbina);
	    stavkeNarudzbineRepository.saveAll(stavke);
	    
	    redirectAttributes.addFlashAttribute("success", "Uspesno ste izvrsili narudzbinu!");

	    session.removeAttribute("korpa");

	    return "redirect:/";
	}

	@GetMapping("/korpa/ocisti/nacin1")
	public String ocistiKorpu1(HttpSession session) {
	    session.removeAttribute("korpa");
	    return "redirect:/";
	}
	
	@GetMapping("/korpa/ocisti/{id}/nacin2")
	public String ocistiKorpu2(@PathVariable int id, HttpSession session) {
	    session.removeAttribute("korpa");
	    return "redirect:/proizvod/" + Integer.toString(id);
	}
}
