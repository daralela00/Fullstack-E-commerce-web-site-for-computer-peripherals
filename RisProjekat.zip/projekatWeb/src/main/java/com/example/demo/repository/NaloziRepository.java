package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import bazaJPA.Dm64924Korisnici;

public interface NaloziRepository extends JpaRepository<Dm64924Korisnici, Integer>{
	boolean existsByUsername(String username);
	boolean existsByEmail(String email);
	Optional<Dm64924Korisnici> findByUsername(String username);
}
