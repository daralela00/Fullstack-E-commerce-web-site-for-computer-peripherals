package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import bazaJPA.Dm64924Slikeproizvoda;

public interface SlikeProizvodaRepository extends JpaRepository<Dm64924Slikeproizvoda, Integer>{
	
}
