package com.example.demo.controller;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.repository.ProizvodRepository;
import com.example.demo.repository.RecenzijeRepository;

import bazaJPA.Dm64924Korisnici;
import bazaJPA.Dm64924Proizvodi;
import bazaJPA.Dm64924Recenzije;
import jakarta.servlet.http.HttpSession;

@Controller
public class ProizvodDetaljiController {
	
	private final ProizvodRepository proizvodRepository;
	private final RecenzijeRepository recenzijeRepository;
	
	public ProizvodDetaljiController(ProizvodRepository proizvodRepository,
									 RecenzijeRepository recenzijeRepository) {
		this.proizvodRepository = proizvodRepository;
		this.recenzijeRepository = recenzijeRepository;
	}
	
	@GetMapping("/proizvod/{id}")
	public String proizvodStranica(@PathVariable int id, Model model, HttpSession session) {
		
		Dm64924Proizvodi proizvod = proizvodRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Kategorija ne postoji"));
		
		List<Dm64924Recenzije> recenzije = recenzijeRepository.findByDm64924ProizvodiIdProizvodi(id);
		
		BigDecimal prosecnaOcena = recenzijeRepository.findByProsecnaOcena(id);
		if (prosecnaOcena == null) {
		    prosecnaOcena = BigDecimal.ZERO;
		} else {
		    prosecnaOcena = prosecnaOcena.setScale(1, RoundingMode.HALF_UP);
		}
		
		session.setAttribute("prosecnaOcena", prosecnaOcena);
		session.setAttribute("recenzije", recenzije);
		session.setAttribute("proizvod", proizvod);
		
		return "proizvodStranica";
	}
	
	@PostMapping("/recenzija/dodaj")
	public String dodajRecenziju(
            @RequestParam("idProizvoda") int idProizvoda,
            @RequestParam("ocena") int ocena,
            @RequestParam("komentar") String komentar,
            HttpSession session,
            RedirectAttributes redirectAttributes) {
		
		String idproizvodaString = Integer.toString(idProizvoda);
		
		Dm64924Korisnici korisnik = (Dm64924Korisnici) session.getAttribute("ulogovaniKorisnik");
		
		List<Dm64924Recenzije> postojeceRecenzije = recenzijeRepository.findByDm64924ProizvodiIdProizvodi(idProizvoda);
	    boolean vecPostavio = postojeceRecenzije.stream()
	            .anyMatch(r -> r.getDm64924Korisnici().getIdKorisnici() == korisnik.getIdKorisnici());

	    if (vecPostavio) {
	        redirectAttributes.addFlashAttribute("error", "Već ste postavili recenziju za ovaj proizvod.");
	        return "redirect:/proizvod/" + idProizvoda;
	    }
		
		Dm64924Proizvodi proizvod = proizvodRepository.findById(idProizvoda)
				.orElseThrow(() -> new RuntimeException("Proizvod ne postoji"));
		
		Dm64924Recenzije recenzija = new Dm64924Recenzije();
		recenzija.setDatum(new Date());
		recenzija.setDm64924Korisnici(korisnik);
		recenzija.setDm64924Proizvodi(proizvod);
		recenzija.setKomentar(komentar);
		recenzija.setOcena(ocena);
		
		recenzijeRepository.save(recenzija);
		
		BigDecimal prosecnaOcena = recenzijeRepository.findByProsecnaOcena(idProizvoda);
		if (prosecnaOcena == null) {
		    prosecnaOcena = BigDecimal.ZERO;
		} else {
		    prosecnaOcena = prosecnaOcena.setScale(1, RoundingMode.HALF_UP);
		}
		
		
        session.setAttribute("prosecnaOcena", prosecnaOcena);
        
		
		return "redirect:/proizvod/" + idproizvodaString;
	}
	
	@PostMapping("/proizvod/{id}/obrisiRecenziju")
    public String obrisiRecenziju(@PathVariable int id,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {

        Dm64924Korisnici ulogovani = (Dm64924Korisnici) session.getAttribute("ulogovaniKorisnik");
        if (ulogovani == null) {
            redirectAttributes.addFlashAttribute("error", "Morate biti prijavljeni da obrišete recenziju.");
            return "redirect:/proizvod/" + id;
        }

        Dm64924Recenzije mojaRecenzija = recenzijeRepository.findByProizvodIdAndKorisnikId(id, ulogovani.getIdKorisnici());
        if (mojaRecenzija != null) {
            recenzijeRepository.delete(mojaRecenzija);
            redirectAttributes.addFlashAttribute("success", "Vaša recenzija je obrisana.");
        } else {
            redirectAttributes.addFlashAttribute("error", "Nemate recenziju za ovaj proizvod.");
        }

        return "redirect:/proizvod/" + id;
    }
}
