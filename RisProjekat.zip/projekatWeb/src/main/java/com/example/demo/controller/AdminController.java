package com.example.demo.controller;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.repository.KategorijaRepository;
import com.example.demo.repository.NaloziRepository;
import com.example.demo.repository.NarudzbineRepository;
import com.example.demo.repository.ProizvodRepository;
import com.example.demo.repository.SlikeProizvodaRepository;
import com.example.demo.repository.StavkeNarudzbineRepository;

import bazaJPA.Dm64924Kategorije;
import bazaJPA.Dm64924Korisnici;
import bazaJPA.Dm64924Narudzbine;
import bazaJPA.Dm64924Proizvodi;
import bazaJPA.Dm64924Slikeproizvoda;
import bazaJPA.Dm64924Stavkenarudzbine;
import jakarta.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Controller
public class AdminController {
	
	private final KategorijaRepository kategorijaRepository;
	private final ProizvodRepository proizvodRepository;
	private final SlikeProizvodaRepository slikeProizvodaRepository;
	private final NaloziRepository naloziRepository;
	private final NarudzbineRepository narudzbineRepository;
	private final StavkeNarudzbineRepository stavkeNarudzbineRepository;
	
	public AdminController(KategorijaRepository kategorijaRepository,
						   ProizvodRepository proizvodRepository,
						   SlikeProizvodaRepository slikeProizvodaRepository,
						   NaloziRepository naloziRepository,
						   NarudzbineRepository narudzbineRepository,
						   StavkeNarudzbineRepository stavkeNarudzbineRepository) {
		this.kategorijaRepository = kategorijaRepository;
		this.proizvodRepository = proizvodRepository;
		this.slikeProizvodaRepository = slikeProizvodaRepository;
		this.naloziRepository = naloziRepository;
		this.narudzbineRepository = narudzbineRepository;
		this.stavkeNarudzbineRepository = stavkeNarudzbineRepository;
	}

	
	@GetMapping("/dodavanjeKategorije")
	public String dodavanjeKategorijeStranica(Model model) {
		
		List<Dm64924Kategorije> kategorije = kategorijaRepository.findAll();
		
		model.addAttribute("kategorije", kategorije);
		
		return "dodajKategoriju";
	}
	
	@PostMapping("/dodavanjeKategorije")
	public String dodavanjeKategorijePost(
										 @RequestParam String naziv,
										 @RequestParam String opis,
										 Model model,
										 RedirectAttributes redirectAttributes) {
		
		if (kategorijaRepository.existsByNaziv(naziv)) {
	        redirectAttributes.addFlashAttribute("error", "Kategorija sa nazivom " + naziv + " već postoji!");
	        return "redirect:/dodavanjeKategorije";
	    }
		
		Dm64924Kategorije kategorija = new Dm64924Kategorije();
		kategorija.setNaziv(naziv);
		kategorija.setOpis(opis);
		
		kategorijaRepository.save(kategorija);
		redirectAttributes.addFlashAttribute("success", "uspesno dodata kategorija sa nazivom: " + naziv);
		return "redirect:/dodavanjeKategorije";
	}
	
	@GetMapping("/brisanjeKategorije")
	public String brisanjeKategorijeStranica(Model model) {
		
		List<Dm64924Kategorije> kategorije = kategorijaRepository.findAll();
		
		model.addAttribute("kategorije", kategorije);
		
		return "obrisiKategoriju";
	}
	
	@PostMapping("/brisanjeKategorije")
	public String dodavanjeKategorijePost(
										 @RequestParam int idKategorije,
										 Model model,
										 RedirectAttributes redirectAttributes) {
		
		Dm64924Kategorije kategorija = kategorijaRepository.findById(idKategorije)
				.orElseThrow(() -> new RuntimeException("Kategorija ne postoji"));

		String naziv = kategorija.getNaziv();
		kategorijaRepository.delete(kategorija);
		redirectAttributes.addFlashAttribute("success", "uspesno obrisana kategorija sa nazivom: " + naziv);
		return "redirect:/brisanjeKategorije";
	}
	
	@GetMapping("/izmenaKategorije")
	public String izmenaKategorijeStranica(Model model) {
		
		List<Dm64924Kategorije> kategorije = kategorijaRepository.findAll();
		
		model.addAttribute("kategorije", kategorije);
		
		return "izmeniKategoriju";
	}
	
	@PostMapping("/izmenaKategorije")
	public String izmenaKategorijePost(
			@RequestParam(required = false) int idKategorije,
			@RequestParam(required = false) String naziv,
			@RequestParam String opis,
			Model model,
			RedirectAttributes redirectAttributes) {
		
		Dm64924Kategorije kategorija = kategorijaRepository.findById(idKategorije)
				.orElseThrow(() -> new RuntimeException("Kategorija ne postoji"));
		
		if(!naziv.isEmpty())
			kategorija.setNaziv(naziv);
		
		if(!opis.isEmpty())
			kategorija.setOpis(opis);

		String nazivTmp = kategorija.getNaziv();
		kategorijaRepository.save(kategorija);
		redirectAttributes.addFlashAttribute("success", "uspesno izmenjena kategorija sa nazivom: " + nazivTmp);
		return "redirect:/izmenaKategorije";
	}
	
	@GetMapping("/dodavanjeProizvoda")
	public String dodavanjeProizvodaStranica(Model model) {
		
		List<Dm64924Kategorije> kategorije = kategorijaRepository.findAll();
		
		model.addAttribute("kategorije", kategorije);
		
		return "dodajProizvod";
	}
	
	@PostMapping("/dodavanjeProizvoda")
	public String dodavanjeProizvodaPost(
										 @RequestParam String naziv,
										 @RequestParam String opis,
										 @RequestParam BigDecimal cena,
										 @RequestParam int lager,
										 @RequestParam int idKategorije,
										 @RequestParam("slika") MultipartFile slika,
										 Model model,
										 RedirectAttributes redirectAttributes) {
		
		if (proizvodRepository.existsByNaziv(naziv)) {
	        redirectAttributes.addFlashAttribute("error", "Kategorija sa nazivom " + naziv + " već postoji!");
	        return "redirect:/dodavanjeProizvoda";
	    }
		
		Dm64924Kategorije kategorija = kategorijaRepository.findById(idKategorije)
				.orElseThrow(() -> new RuntimeException("Kategorija ne postoji"));
		
		
		
		Dm64924Proizvodi proizvod = new Dm64924Proizvodi();
		proizvod.setNaziv(naziv);
		proizvod.setOpis(opis);
		proizvod.setCena(cena);
		proizvod.setLager(lager);
		proizvod.setKreiran(new Date());
		proizvod.setDm64924Kategorije(kategorija);
		
		proizvodRepository.save(proizvod);
		
		Dm64924Slikeproizvoda slikaProizvoda = new Dm64924Slikeproizvoda();
		
		String uploadDir = "src/main/resources/static/images/";
		try {
			Files.createDirectories(Paths.get(uploadDir));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String originalniNaziv = slika.getOriginalFilename();
		String ekstenzija = originalniNaziv.substring(originalniNaziv.lastIndexOf("."));
		String nazivFajla = UUID.randomUUID() + ekstenzija;

		Path putanjaFajla = Paths.get(uploadDir + nazivFajla);
		try {
			Files.write(putanjaFajla, slika.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String urlSlike = "/images/" + nazivFajla;
		
		slikaProizvoda.setDm64924Proizvodi(proizvod);
		slikaProizvoda.setUrlSlike(urlSlike);
		
		slikeProizvodaRepository.save(slikaProizvoda);
		
		redirectAttributes.addFlashAttribute("success", "uspesno dodat proizvod sa nazivom: " + naziv);
		return "redirect:/dodavanjeProizvoda";
	}
	
	@GetMapping("/brisanjeProizvoda")
	public String brisanjeProizvodaStranica(Model model) {
		
		List<Dm64924Proizvodi> proizvodi = proizvodRepository.findAll();
		
		model.addAttribute("sviProizvodi", proizvodi);
		
		return "obrisiProizvod";
	}
	
	@PostMapping("/brisanjeProizvoda")
	public String brisanjeProizvodaPost(
										 @RequestParam int idProizvoda,
										 Model model,
										 RedirectAttributes redirectAttributes) {
		
		Dm64924Proizvodi proizvod = proizvodRepository.findById(idProizvoda)
				.orElseThrow(() -> new RuntimeException("Proizvod ne postoji"));
		
		String putanjaFolder = "C:/Users/Korisnik/eclipse-workspace/projekatWeb/src/main/resources/static/images/";
		
		String urlSlike = proizvod.getDm64924Slikeproizvodas().get(0).getUrlSlike();
		String imeSlike = urlSlike.replace("/images/", "");
		
		Path putanja = Paths.get(putanjaFolder, imeSlike);
		
		try {
			Files.delete(putanja);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String naziv = proizvod.getNaziv();
		proizvodRepository.delete(proizvod);
		redirectAttributes.addFlashAttribute("success", "uspesno dodata kategorija sa nazivom: " + naziv);
		return "redirect:/brisanjeProizvoda";
	}
	
	@GetMapping("/izmenaProizvoda")
	public String izmenaProizvodaStranica(Model model) {
		
		List<Dm64924Proizvodi> proizvod = proizvodRepository.findAll();
		
		model.addAttribute("sviProizvodi", proizvod);
		
		return "izmeniProizvod";
	}
	
	@PostMapping("/izmenaProizvoda")
	public String izmenaProizvodaPost(
			@RequestParam(required = false) int idProizvoda,
			@RequestParam(required = false) String naziv,
			@RequestParam(required = false) String opis,
			@RequestParam(required = false) BigDecimal cena,
			@RequestParam(required = false) Integer lager,
			@RequestParam("slika") MultipartFile slika,
			Model model,
			RedirectAttributes redirectAttributes) {
		
		Dm64924Proizvodi proizvod = proizvodRepository.findById(idProizvoda)
				.orElseThrow(() -> new RuntimeException("Proizvod ne postoji"));
		
		if(!naziv.isEmpty())
			proizvod.setNaziv(naziv);
		
		if(!opis.isEmpty())
			proizvod.setOpis(opis);
		
		if(cena != null)
			proizvod.setCena(cena);
		
		if(lager != null)
			proizvod.setLager(lager);
		
		if(slika != null && !slika.isEmpty()) {
			String putanjaFolder = "C:/Users/Korisnik/eclipse-workspace/projekatWeb/src/main/resources/static/images/";
			
			String nazivStareSlike = proizvod.getDm64924Slikeproizvodas().get(0).getUrlSlike().replace("/images/", "");
			
			String putanja = putanjaFolder + nazivStareSlike;
			
			try {
				Files.delete(Paths.get(putanja));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		String uploadDir = "C:/Users/Korisnik/eclipse-workspace/projekatWeb/src/main/resources/static/images/";
		String originalniNaziv = slika.getOriginalFilename();
		String ekstenzija = originalniNaziv.substring(originalniNaziv.lastIndexOf("."));
		String nazivFajla = UUID.randomUUID() + ekstenzija;

		Path putanjaFajla = Paths.get(uploadDir + nazivFajla);
		try {
			Files.write(putanjaFajla, slika.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String urlSlike = "/images/" + nazivFajla;
		
		Dm64924Slikeproizvoda slikaProizvoda = proizvod.getDm64924Slikeproizvodas().get(0);
		
		slikaProizvoda.setDm64924Proizvodi(proizvod);
		slikaProizvoda.setUrlSlike(urlSlike);
		
		slikeProizvodaRepository.save(slikaProizvoda);
		

		String nazivTmp = proizvod.getNaziv();
		proizvodRepository.save(proizvod);
		redirectAttributes.addFlashAttribute("success", "Uspesno izmenjen proizvod sa nazivom: " + nazivTmp);
		return "redirect:/izmenaProizvoda";
	}
	
	@RequestMapping(value="/spisakSvihKorisnika.pdf", method=RequestMethod.GET)
	public void spisakSvihKorisnikaReport (HttpServletResponse response) {
		
		try {
			InputStream reportStream = getClass().getResourceAsStream("/jasperreports/spisakSvihKorisnika.jrxml");
	
		    JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);
	
		    Map<String, Object> params = new HashMap<>();
	
		    List<Dm64924Korisnici> korisnici = naloziRepository.findAll();
	
		    JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(korisnici);
	
		    JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, dataSource);
	
		    response.setContentType("application/pdf");
		    response.setHeader("Content-Disposition", "attachment; filename=spisakSvihKorisnika.pdf");
	
		    JasperExportManager.exportReportToPdfStream( jasperPrint, response.getOutputStream());
		} catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	@GetMapping("/spisakNarudzbina")
	public String najprodavanijiProizvodiStranica (Model model) {
		List<Dm64924Proizvodi> proizvodi = proizvodRepository.findAll();
		
		model.addAttribute("sviProizvodi", proizvodi);
		
		return "spisakNarudzbina";
	}
	
	@RequestMapping(value="/spisakNarudzbina.pdf", method=RequestMethod.GET)
	public void spisakNarudzbinaReport (HttpServletResponse response, @RequestParam("datOd") @DateTimeFormat(pattern="yyyy-MM-dd") Date datOd, @RequestParam("datDo") @DateTimeFormat(pattern="yyyy-MM-dd") Date datDo) throws Exception {
		InputStream reportStream = getClass().getResourceAsStream("/jasperreports/narudzbineUPeriodu.jrxml");
		
	    JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);

	    Map<String, Object> params = new HashMap<>();
	    params.put("datOd", datOd);
	    params.put("datDo", datDo);

	    List<Dm64924Narudzbine> narudzbine = narudzbineRepository.narudzbineUPeriodu(datOd, datDo);

	    JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(narudzbine);

	    JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, dataSource);

	    response.setContentType("application/pdf");
	    response.setHeader("Content-Disposition", "attachment; filename=narudzbineUPeriodu.pdf");
	    
	    JasperExportManager.exportReportToPdfStream( jasperPrint, response.getOutputStream());
	}
	
	@GetMapping("/spisakStavkiNarudzbine")
	public String spisaStavkiNarudzbineStranica (Model model) {
		List<Dm64924Proizvodi> proizvodi = proizvodRepository.findAll();
		
		model.addAttribute("sviProizvodi", proizvodi);
		
		return "spisakStavkiNarudzbine";
	}
	
	@RequestMapping(value="/spisakStavkiNarudzbine.pdf", method=RequestMethod.GET)
	public void spisakNarudzbinaReport (HttpServletResponse response, @RequestParam("idNarudzbine") int idNarudzbine) throws Exception {
		InputStream reportStream = getClass().getResourceAsStream("/jasperreports/stavkeNarudzbine.jrxml");
		
	    JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);

	    Map<String, Object> params = new HashMap<>();
	    params.put("idNarudzbine", idNarudzbine);

	    List<Dm64924Stavkenarudzbine> stavkeNarudzbine = stavkeNarudzbineRepository.stavkeNarudzbine(idNarudzbine);

	    JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(stavkeNarudzbine);

	    JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, dataSource);

	    response.setContentType("application/pdf");
	    response.setHeader("Content-Disposition", "attachment; filename=StavkeNarudzbine.pdf");
	    
	    JasperExportManager.exportReportToPdfStream( jasperPrint, response.getOutputStream());
	}
	
}
