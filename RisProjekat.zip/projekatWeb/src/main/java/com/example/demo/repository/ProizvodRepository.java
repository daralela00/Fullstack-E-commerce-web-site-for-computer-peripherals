package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import bazaJPA.Dm64924Proizvodi;

public interface ProizvodRepository extends JpaRepository<Dm64924Proizvodi, Integer>{
	List<Dm64924Proizvodi> findByDm64924KategorijeIdKategorije(int idKategorije);
	
	boolean existsByNaziv(String naziv);
}
