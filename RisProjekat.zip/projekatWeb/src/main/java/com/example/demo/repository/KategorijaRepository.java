package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import bazaJPA.Dm64924Kategorije;

public interface KategorijaRepository extends JpaRepository<Dm64924Kategorije, Integer> {
	boolean existsByNaziv(String naziv);
}
