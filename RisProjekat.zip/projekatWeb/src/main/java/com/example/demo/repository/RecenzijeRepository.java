package com.example.demo.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import bazaJPA.Dm64924Recenzije;

public interface RecenzijeRepository extends JpaRepository<Dm64924Recenzije, Integer>{
	List<Dm64924Recenzije> findByDm64924ProizvodiIdProizvodi (int idProizvodi);
	
	@Query("SELECT AVG(r.ocena) FROM Dm64924Recenzije r WHERE r.dm64924Proizvodi.idProizvodi = :idProizvodi")
	BigDecimal findByProsecnaOcena (@Param("idProizvodi") int idProizvodi);
	
	@Query("SELECT r FROM Dm64924Recenzije r WHERE r.dm64924Proizvodi.idProizvodi = :idProizvodi AND r.dm64924Korisnici.idKorisnici = :idKorisnici")
	Dm64924Recenzije findByProizvodIdAndKorisnikId(@Param("idProizvodi") int idProizvodi, @Param("idKorisnici") int idKorisnici);
}
