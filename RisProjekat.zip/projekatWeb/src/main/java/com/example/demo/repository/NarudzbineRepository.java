package com.example.demo.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import bazaJPA.Dm64924Narudzbine;

public interface NarudzbineRepository extends JpaRepository<Dm64924Narudzbine, Integer>{
	
	@Query("SELECT n FROM Dm64924Narudzbine n WHERE n.datum BETWEEN :datOd AND :datDo order by n.datum")
	public List<Dm64924Narudzbine> narudzbineUPeriodu(@Param("datOd")Date datOd, @Param("datDo")Date datDo);
}