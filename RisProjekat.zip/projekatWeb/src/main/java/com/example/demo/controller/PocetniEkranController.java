package com.example.demo.controller;

import com.example.demo.repository.KategorijaRepository;
import com.example.demo.repository.ProizvodRepository;

import bazaJPA.Dm64924Kategorije;
import bazaJPA.Dm64924Proizvodi;
import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class PocetniEkranController {

    private final KategorijaRepository kategorijaRepository;
    private final ProizvodRepository proizvodRepository;

    public PocetniEkranController(KategorijaRepository kategorijaRepository, ProizvodRepository proizvodRepository) {
        this.kategorijaRepository = kategorijaRepository;
        this.proizvodRepository = proizvodRepository;
    }

    @GetMapping("/")
    public String pocetniEkran(Model model, HttpSession session) {

        List<Dm64924Kategorije> kategorije = kategorijaRepository.findAll();
        List<Dm64924Proizvodi> sviProizvodi = proizvodRepository.findAll();
        
        Map<Integer, Dm64924Proizvodi> proizvodiMap = sviProizvodi.stream()
                .collect(Collectors.toMap(Dm64924Proizvodi::getIdProizvodi, p -> p));
        
        session.setAttribute("proizvodiMap", proizvodiMap);
        session.setAttribute("kategorije", kategorije);

        return "pocetniEkran";
    }
    
    @GetMapping("/kategorija/{id}")
    public String prikazKategorije(@PathVariable int id, Model model, HttpSession session) {
    	
    	List<Dm64924Kategorije> kategorije = kategorijaRepository.findAll();
    	
    	Dm64924Kategorije kategorija = kategorijaRepository.findById(id)
    			.orElseThrow(() -> new RuntimeException("Kategorija ne postoji"));
    			
    	
    	List<Dm64924Proizvodi> proizvodi = proizvodRepository.findByDm64924KategorijeIdKategorije(id);
    	
    	session.setAttribute("kategorije", kategorije);
    	session.setAttribute("kategorija", kategorija);
    	session.setAttribute("proizvodi", proizvodi);
    	
    	return "pocetniEkran";
    }
}
